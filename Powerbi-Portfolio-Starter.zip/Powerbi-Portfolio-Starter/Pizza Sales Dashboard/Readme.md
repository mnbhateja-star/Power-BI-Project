# 🍕 Pizza Sales Analysis Dashboard (Power BI)

## 🎯 Objective
Analyze sales performance, revenue trends, and customer behavior.

## 📊 KPIs
- Total Revenue: 817.86K
- Total Pizzas Sold: 50K
- Average Order Value: 38
- Total Orders: 21K

## 🔍 Key Insights
- Friday busiest, Sunday slowest.
- Classic pizzas lead in revenue.
- Large size contributes ~36%.
- Peak timing: 12–2 PM.

## 🛠 Tools
- Power BI (DAX, Power Query)
- CSV dataset
- Data visualization best practices

## 📂 Files
- `Pizza_Sales_Dashboard.pbix` → Power BI file
- `data.csv` → Dataset
- `assets/` → Screenshots & visuals
