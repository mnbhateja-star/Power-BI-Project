# 📊 Power BI Portfolio

This repository showcases my Business & Data Analytics projects built in **Power BI**.  
Each project folder contains the `.pbix` file, dataset (or data source notes), screenshots/GIF, and a README with objectives, metrics, and insights.

## 🔧 Tech Stack
- Power BI · DAX · Power Query
- SQL (for preprocessing where applicable)
- Excel / CSV datasets

## 📁 Projects
- [Pizza Sales Dashboard](./Pizza-Sales-Dashboard/README.md)
