# 📊 Superstore Sales Dashboard – Power BI  

This project showcases a **Power BI dashboard** built using the Superstore dataset.  
The aim was to analyze sales, profit, and customer trends across regions, categories, and segments.  

## 🔹 Key Insights  
- 💰 **Total Sales**: 2.3M  
- 📦 **Quantity Sold**: 38K+  
- 📈 **Profit**: 286K  
- 🌍 **West region** leads in sales  
- 👥 **Consumer segment** is the top contributor  
- 🖥 **Technology** category performs the best  
- 📊 Clear **YoY growth** in sales & profit  

## 🔹 Features of Dashboard  
- Regional Sales & Profit Analysis  
- Customer Segment Performance  
- Category & Sub-Category Comparison  
- Payment & Shipping Insights  
- Year-on-Year Trend Analysis  

## 📂 Files Included  
- `Superstore_Dashboard.pbix` → Power BI file  
- `Superstore_Dataset.csv` → Raw dataset  
- `Dashboard_Screenshot.png` → Snapshot of dashboard  

## 🚀 How to Use  
1. Download the `.pbix` file  
2. Open in **Power BI Desktop**  
3. Connect with the dataset (if needed)  
4. Explore the dashboard & modify as per your use case  

## 📌 Tools Used  
- Power BI Desktop  
- Superstore Dataset (Sample)  

---  

⚡ If you find this project useful, don’t forget to ⭐ the repo!  
